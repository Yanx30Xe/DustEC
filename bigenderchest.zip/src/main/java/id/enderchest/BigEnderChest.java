package id.enderchest;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * BigEnderChest - ganti GUI ender chest vanilla (3 baris) jadi lebih gede.
 *
 * Cara kerja: tiap kali ada pemain buka ender chest (dari block atau dari plugin lain),
 * pembukaan vanilla dibatalin lalu diganti inventory custom. Isi disimpen di
 * plugins/BigEnderChest/data/<uuid>.yml. Isi ender chest vanilla yang lama otomatis
 * dipindah ke inventory baru (posisi slot dijaga), lalu dikosongin biar nggak dobel.
 */
public class BigEnderChest extends JavaPlugin implements Listener {

    private int rows = 5;
    private Component title = Component.text("Ender Chest");
    private File dataDir;

    /** Satu inventory per pemain, dipake bareng semua yang ngelihat. */
    private final Map<UUID, Inventory> boxes = new HashMap<>();

    /** Penanda inventory ender chest custom. */
    public static class EnderHolder implements InventoryHolder {
        private final UUID owner;
        private Inventory inventory;

        public EnderHolder(UUID owner) {
            this.owner = owner;
        }

        public UUID getOwner() {
            return owner;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override
    public void onEnable() {
        saveDefaultConfig();
        rows = Math.max(1, Math.min(6, getConfig().getInt("rows", 5)));
        title = LegacyComponentSerializer.legacyAmpersand()
                .deserialize(getConfig().getString("title", "&5Ender Chest"));

        dataDir = new File(getDataFolder(), "data");
        if (!dataDir.exists() && !dataDir.mkdirs()) {
            getLogger().warning("Gagal bikin folder data!");
        }

        Bukkit.getPluginManager().registerEvents(this, this);

        if (getCommand("ec") != null) {
            getCommand("ec").setExecutor(this);
        }

        // Autosave tiap 5 menit biar aman kalau server crash
        Bukkit.getScheduler().runTaskTimer(this, this::saveAll, 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        saveAll();
    }

    // ------------------------------------------------------------------
    // Penyimpanan
    // ------------------------------------------------------------------

    private File fileOf(UUID id) {
        return new File(dataDir, id + ".yml");
    }

    private void saveAll() {
        for (Map.Entry<UUID, Inventory> en : boxes.entrySet()) {
            save(en.getKey(), en.getValue());
        }
    }

    private void save(UUID id, Inventory inv) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("version", 1);
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (it == null || it.getType().isAir()) {
                continue;
            }
            y.set("slots." + i, Base64.getEncoder().encodeToString(it.serializeAsBytes()));
        }
        File target = fileOf(id);
        File tmp = new File(dataDir, id + ".yml.tmp");
        try {
            y.save(tmp);
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            getLogger().severe("Gagal nyimpen ender chest " + id + ": " + e.getMessage());
        }
    }

    /** Ambil (atau muat) inventory ender chest gede milik pemain. */
    private Inventory box(Player owner) {
        UUID id = owner.getUniqueId();
        Inventory cached = boxes.get(id);
        if (cached != null) {
            return cached;
        }

        EnderHolder holder = new EnderHolder(id);
        Inventory inv = Bukkit.createInventory(holder, rows * 9, title);
        holder.inventory = inv;

        List<ItemStack> overflow = new ArrayList<>();

        // 1) Muat dari file
        File f = fileOf(id);
        if (f.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            ConfigurationSection sec = y.getConfigurationSection("slots");
            if (sec != null) {
                for (String key : sec.getKeys(false)) {
                    int slot;
                    try {
                        slot = Integer.parseInt(key);
                    } catch (NumberFormatException ex) {
                        continue;
                    }
                    String b64 = sec.getString(key);
                    if (b64 == null) {
                        continue;
                    }
                    try {
                        ItemStack it = ItemStack.deserializeBytes(Base64.getDecoder().decode(b64));
                        if (slot >= 0 && slot < inv.getSize() && inv.getItem(slot) == null) {
                            inv.setItem(slot, it);
                        } else {
                            overflow.add(it);
                        }
                    } catch (Exception ex) {
                        getLogger().warning("Item rusak di " + id + " slot " + key + ": " + ex.getMessage());
                    }
                }
            }
        }

        // 2) Pindahin isi ender chest vanilla (kalau ada) ke inventory gede, posisi dijaga
        Inventory vanilla = owner.getEnderChest();
        ItemStack[] old = vanilla.getContents();
        boolean hadVanilla = false;
        for (int i = 0; i < old.length; i++) {
            ItemStack it = old[i];
            if (it == null || it.getType().isAir()) {
                continue;
            }
            hadVanilla = true;
            if (i < inv.getSize() && inv.getItem(i) == null) {
                inv.setItem(i, it.clone());
            } else {
                overflow.add(it.clone());
            }
        }
        if (hadVanilla) {
            vanilla.clear();
        }

        // 3) Yang nggak muat: ke slot kosong lain, lalu inventory pemain, lalu dijatuhin
        for (ItemStack it : overflow) {
            Map<Integer, ItemStack> left = inv.addItem(it);
            for (ItemStack l : left.values()) {
                Map<Integer, ItemStack> left2 = owner.getInventory().addItem(l);
                for (ItemStack d : left2.values()) {
                    owner.getWorld().dropItemNaturally(owner.getLocation(), d);
                }
            }
        }

        boxes.put(id, inv);
        if (hadVanilla || !overflow.isEmpty() || !f.exists()) {
            save(id, inv); // langsung simpen hasil migrasi
        }
        return inv;
    }

    // ------------------------------------------------------------------
    // Event
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent e) {
        if (e.getInventory().getType() != InventoryType.ENDER_CHEST) {
            return;
        }
        if (!(e.getPlayer() instanceof Player)) {
            return;
        }
        final Player viewer = (Player) e.getPlayer();

        // Kalau ender chest itu milik pemain lain (misal admin ngintip), buka punya dia
        final Player owner;
        InventoryHolder holder = e.getInventory().getHolder();
        if (holder instanceof Player) {
            owner = (Player) holder;
        } else {
            owner = viewer;
        }

        e.setCancelled(true);
        Bukkit.getScheduler().runTask(this, () -> openFor(viewer, owner));
    }

    private void openFor(Player viewer, Player owner) {
        if (!viewer.isOnline() || !owner.isOnline()) {
            return;
        }
        viewer.openInventory(box(owner));
        viewer.playSound(viewer.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1f);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        InventoryHolder holder = e.getInventory().getHolder();
        if (!(holder instanceof EnderHolder)) {
            return;
        }
        EnderHolder h = (EnderHolder) holder;
        save(h.getOwner(), e.getInventory());
        if (e.getPlayer() instanceof Player) {
            Player p = (Player) e.getPlayer();
            p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_CLOSE, 0.8f, 1f);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Inventory inv = boxes.get(id);
        if (inv == null) {
            return;
        }
        save(id, inv);
        // Kalau nggak ada yang lagi ngebuka, buang dari memori
        if (inv.getViewers().isEmpty()) {
            boxes.remove(id);
        }
    }

    // ------------------------------------------------------------------
    // Command /ec
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Command ini cuma buat pemain.");
            return true;
        }
        Player p = (Player) sender;
        openFor(p, p);
        return true;
    }
}
